<html>
    <head>
        <meta charset="UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link href="{{ asset('public/css/dataTables.bootstrap.min.css')}}" rel="stylesheet" type="text/css"/>
        <link href="{{ asset('public/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css"/>
        <link href="{{ asset('public/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css"/>
        <script src="{{ asset('public/js/jquery-3.1.1.min.js') }}" type="text/javascript"></script>
        <script src="{{ asset('public/js/jquery.dataTables.js') }}" type="text/javascript"></script>
        <script src="{{ asset('public/js/admin.js') }}" type="text/javascript"></script>
        <link href="{{ asset('public/css/styleAdmin.css') }}" rel="stylesheet" type="text/css"/>
        
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.5/css/bootstrap.min.css">
        <link href="{{ asset('public/css/bootstrap-tagsinput.css') }}" rel="stylesheet" type="text/css"/>
    </head>
    <body>