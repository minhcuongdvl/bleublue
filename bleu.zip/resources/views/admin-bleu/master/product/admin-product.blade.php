@include('admin-bleu.soure_module.head-admin')

@include('admin-bleu.product.list.list-product')