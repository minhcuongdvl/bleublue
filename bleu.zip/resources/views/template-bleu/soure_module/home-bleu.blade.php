<div class="home">
    <div id="bg"><img width="100%" height="100%" src="{{ asset('public/image/background.png')}}" /></div> 
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="content-one">
                    <a href="https://www.w3schools.com" class="button w3-black">
                    
                        1 9<br>3 7
                   
                        </a>
                    <p class="text-one">z2a</p>
                </div>
                <div class="content-tow">
                    <div class="text-tow">
                        <div class="text-align">
                        <p class="text">é</p>
                        </div>
                    </div>
                    <div class="text-tow">
                        
                        <div class="logo-blue">
                            <a href="{!! URL::route('list-product') !!}" class="logo">
                                  BLEUBLUE
                              </a>
                            <br><p class="logo-sub">Milano</p>
                            <br>
                            <p class="fxxk">Fxxk</p>
                        </div>
                  
                        </div>
                    <div class="text-tow">
                        <div class="text-align-number">
                    <p class="text-three">0 1 2 3 4 5<br>6 7 8 9<br>10 a</p><br>
                    <p class="text-2">2</p>
                    </div>
                    </div>
                </div>
              
            </div>
        </div>
        <div class="row">
            <div class="content-three">
               
                    <a href="https://www.w3schools.com" class="artwork">artwork studio </a>
                   
                    <p class="text-three">178 1/2</p>
                    
                </div>
        </div>
    </div>
</div>