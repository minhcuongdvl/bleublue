<?php echo $__env->make('admin-bleu.soure_module.head-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('admin-bleu.product.add.add-product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>