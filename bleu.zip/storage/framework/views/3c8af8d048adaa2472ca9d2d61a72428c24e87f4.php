<div class="list-bleu">
    <div id="bg"><img width="100%" height="100%" src="<?php echo e(asset('public/image/background.png')); ?>" /></div>  
    <div class="container">
        <div class="row">
            <div class='head'>
            <div class="col-sm-6 col-xs-2">
                <div class='logo'>
                    <p  class="button w3-black"> MENU</p>
                </div>
            </div>
            <div class="col-sm-6">
                <div class='login-acnout'>
                    <a href="#">LOGIN / ACNOUT</a>
                </div>
            </div>
                </div>
        </div>
        
        <div class="row">
            <div class="col-sm-2 ">
                <div class="list-menu">
                <ul>
                    <?php $__currentLoopData = $datacat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo URL::route('list-productcat',$cat->categories_slug); ?>"><?php echo e($cat->categories_name); ?></a></li>
                   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    
                                                            
                </ul>
              </div>

            </div>
            <div class="col-sm-8">
                <div class="list">
                <div class="row">
                    <div class="title">
                        <p>MAISON BLEUBLUE</p>
                    </div>
                     <?php $__currentLoopData = $dataproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if(!empty($product)): ?>
                    <div class="col-md-4 col-sm-6">
                           <div class="list-product">
                               <a href="<?php echo URL::route('detail-product',$product->id); ?>">
                                <img src="<?php echo e(asset('public/bleu-blue/image/')); ?>/<?php echo e($product->product_image); ?>" alt=""/>
                                <figure class="bginfo">
                            <span class="name"><?php echo e($product->product_name); ?></span>
                            <strong><?php echo e($product->product_price); ?> VNĐ</strong>
                                
                        </figure>
                               </a>
                            </div>
                        
                     </div>
                    <?php endif; ?>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                   
                </div>
                </div>
            </div>
            
            <div class="col-sm-2">
                
            </div>
            
        </div>
    </div>
</div>