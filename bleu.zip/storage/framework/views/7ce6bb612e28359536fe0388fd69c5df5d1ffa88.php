<?php echo $__env->make('template-bleu.soure_module.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('template-bleu.soure_module.listproduct-bleu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>