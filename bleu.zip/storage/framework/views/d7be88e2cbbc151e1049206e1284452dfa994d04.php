 <div class="admin">
            <div class="head_admin">

            </div>
            <div class="content_admin">
                <div class="col2">
                  <?php echo $__env->make('admin-bleu.soure_module.sidebar-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div style="clear: both;"></div>
                </div>
                <div class="col10">
                    <div class="contentfull">
                        <div class="content">
                            <h1 id="h1">
                                Quản lí Category product
                                <a id="a1" href="./addcategory" class="fa fa-plus"> Thêm</a>
                                <div style="clear: both;"></div>
                            </h1>
                            <?php if(Session::has('flash_message')): ?>
                            <div class="alert alert-<?php echo Session::get('flash_level'); ?>">
                                <?php echo Session::get('flash_message'); ?>

                            </div>
                            <?php endif; ?>
                            <div class="content-item">
                                <table id="myTable" class="table table-striped " cellspacing="0" width="100%">
                                    <thead>
                                        <tr id="tr-first">
                                            <th style="width: 10%;">STT</th>
                                            <th style="width:13%;">Tên Category</th>
                                           
                                            <th style="width: 15%;"></th>
                                            
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $id = 0;?>
                                         <?php $__currentLoopData = $datacategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         
                                        <tr>
                                            <td><?php echo $id = $id+1?></td>
                                            <td><?php echo e($data->categories_name); ?></td>                                            
                                          
                                            <td>
                                                <a href="<?php echo URL::route('deletecategory',$data->categories_id); ?>" style="background: #575757;padding: 5px;color: white;border-radius: 10px;" onclick="return xacnhanxoa('Bạn Có Muốn Xóa hay không')">Xóa</a>
                                                <a href="<?php echo URL::route('editcategory',$data->categories_id); ?>" style="background: #575757;padding: 5px;color: white;border-radius: 10px;">Sửa</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </tbody>
                                </table>
                                <script>
                                    $(document).ready(function () {
                                        $('#myTable').DataTable();
                                    });
                                </script>

                            </div>
                        </div>
                    </div>
                </div>
                <div style="clear: both;"></div>
            </div>
        </div>
    </body>
    <script>
       
   
 
    </script>
</html>